# require 'faker'

# FactoryBot.define do
#   factory :order do |f|
#     f.user_id { Faker::Number.digit }
#     f.subtotal { 50.0 }
#     f.status { 'shipped' }
#   end
# end